package sms;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class StudentService implements IStudentService {
	
	Scanner scan = new Scanner(System.in);
	
	@Override
	public Student addStudent() {
		System.out.print("Enter the student id : ");
		int id = scan.nextInt();
		scan.nextLine();
		
		System.out.print("Enter the student name : ");
		String name = scan.nextLine();
		
		System.out.print("Enter the student rollno : ");
		int rollno = scan.nextInt();
		
		System.out.print("Enter the student fees : ");
		double fees = scan.nextDouble();
		
		Student s1 = new Student(id,name,rollno,fees);
		
		return s1;
	}
	
	@Override
	public Set<Student> showStudents(Set<Student> ts) {
		return ts;
	}
	
	@Override
	public Student showStudentById(Set<Student> ts) {
		System.out.print("Enter the Id to show : ");
		int id = scan.nextInt();
		scan.nextLine();
		
		for(Student student : ts) {
			if(id == student.getId()) {
				return student;
			}
		}
		
		return null;
	}
	
	@Override
	public Set<Student> updateStudent(Set<Student> ts) {
		System.out.print("Enter the Id to update : ");
		int id = scan.nextInt();
		scan.nextLine();
		
		for(Student student : ts) {
			if(id == student.getId()) {

				System.out.print("Enter the student name : ");
				String name = scan.nextLine();
				
				System.out.print("Enter the student rollno : ");
				int rollno = scan.nextInt();
				
				System.out.print("Enter the student fees : ");
				double fees = scan.nextDouble();
				
				student.setId(id);
				student.setName(name);
				student.setRollno(rollno);
				student.setFees(fees);
				
				return ts;
			}
		}
		
		return null;
	}
	
	@Override
	public Set<Student> deleteStudent(Set<Student> ts){
		System.out.print("Enter the Id to delete : ");
		int id = scan.nextInt();
		scan.nextLine();
		
		for(Student student : ts) {
			if(id == student.getId()) {

				ts.remove(student);
				
				return ts;
			}
		}
		return null;
	}
}
