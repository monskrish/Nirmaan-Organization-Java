package sms;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class UserInterface {
	public static void main(String[] args) {
		
		
		Set<Student> ts = new TreeSet<Student>();
		Scanner scan = new Scanner(System.in);
		StudentService service = new StudentService();
		
		
		while(true) {
			System.out.println("Choose one below \n 1 for Add a student \n 2 for Show the students \n 3 for Show one student \n 4 for Update the student \n 5 for Delete the student");
			int key = scan.nextInt();
			
			if(key==1) {
				ts.add(service.addStudent());
			}else if(key==2) {
				System.out.println(service.showStudents(ts));
			}else if(key==3) {
				System.out.println(service.showStudentById(ts));
			}else if(key==4) {
				ts = service.updateStudent(ts);
			}else if(key==5) {
				ts = service.deleteStudent(ts);
			}
		}
		
		
		
	}
}
