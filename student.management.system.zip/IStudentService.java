package sms;

import java.util.Set;

public interface IStudentService {

	public Student addStudent();
	public Set<Student> showStudents(Set<Student> ts);
	public Student showStudentById(Set<Student> ts);
	public Set<Student> updateStudent(Set<Student> ts);
	public Set<Student> deleteStudent(Set<Student> ts);
}
