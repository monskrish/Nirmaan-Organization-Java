//day 24

package library;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class BookService {
	
	Scanner sc = new Scanner(System.in);
	
	//add book method
	public Book addbook() {
		System.out.print("Enter the book id : ");
		int id = sc.nextInt();
		sc.nextLine();
		System.out.print("Enter the book name : ");
		String bookName = sc.nextLine();
		System.out.print("Enter the book author name : ");
		String author = sc.nextLine();
		System.out.println("Enter the book price : ");
		double price = sc.nextDouble();
		
		return new Book(id,bookName,author,price);
	}
	
	//read books method
	public void getBooks(ArrayList<Book> book) {
		System.out.println(book);
	}
	
	//read book by Id
	public Book getBookById(int id,ArrayList<Book> book) {
		
		for(Book b : book) {
			if(b.getId() == id) {
				return b;
			}
		}
		
		return null;
	}
	
	public ArrayList<Book> updateBook(int id,ArrayList<Book> books){
		
		for(Book book : books) {
			if(book.getId()==id) {
				System.out.print("Enter the book name : ");
				String bookName = sc.nextLine();
				System.out.print("Enter the book author name : ");
				String author = sc.nextLine();
				System.out.println("Enter the book price : ");
				double price = sc.nextDouble();
				
				book.setAuthor(author);
				book.setPrice(price);
				book.setBookName(bookName);
				
				
			}
		}
		return books;
	}
	
	public ArrayList<Book> deleteBook(int id, ArrayList<Book> books) {
		for(Book book : books) {
			if(book.getId()==id) {
				books.remove(book);
				return books;
			}
		}
		return books;
	}
}
