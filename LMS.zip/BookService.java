package library;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class BookService {
	
	Scanner sc = new Scanner(System.in);
	
	//add book method
	public Book addbook() {
		System.out.print("Enter the book id : ");
		int id = sc.nextInt();
		sc.nextLine();
		System.out.print("Enter the book name : ");
		String bookName = sc.nextLine();
		System.out.print("Enter the book author name : ");
		String author = sc.nextLine();
		System.out.println("Enter the book price : ");
		double price = sc.nextDouble();
		
		return new Book(id,bookName,author,price);
	}
	
	//read books method
	public void getBooks(ArrayList<Book> book) {
		System.out.println(book);
	}
	
	//read book by Id
	public Book getBookById(int id,ArrayList<Book> book) {
		
		for(Book boo : book) {
			if(boo.getId() == id) {
				return boo;
			}
		}
		
		return null;
	}
}
