package library;

import java.util.Scanner;
import java.util.ArrayList;

public class UserInterface {
	public static void main(String[] args) {
		ArrayList<Book> al = new ArrayList<Book>();
		
		Scanner sc = new Scanner(System.in);
		
		BookService service = new BookService();
		
		while(true) {
			System.out.println("Enter your choice \n 1 for add Book \n 2 for show Books \n 3 for search Book by Id");
			
			int key = sc.nextInt();
			
			if(key == 1) {
				al.add(service.addbook());
			}
			else if(key == 2) {
				service.getBooks(al);
			}
			else if(key == 3) {
				System.out.print("Enter the book Id : ");
				int id = sc.nextInt();
				System.out.println(service.getBookById(id, al));
			}
		}
	}
}
