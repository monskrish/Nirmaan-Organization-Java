package com.axisbank;

import java.util.*;

public interface IUserService {
    User addUser();
    void getAllUsers(Set<User> users);
    User getUserById(Set<User> users, int id);
    Set<User> updateUser(Set<User> users, int id);
    Set<User> deleteUser(Set<User> users, int id);
}
