package com.axisbank;

import java.io.*;
import java.util.*;

public class UserRepository {
    private static final String FILE_NAME = "users.txt";

    public void saveUsers(Set<User> users) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(new ArrayList<>(users));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Set<User> loadUsers() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            List<User> list = (List<User>) ois.readObject();
            return new TreeSet<>(list);
        } catch (IOException | ClassNotFoundException e) {
            return new TreeSet<>();
        }
    }
}

