package com.axisbank;

import java.util.*;

public class UserService implements IUserService {
    private Scanner scanner = new Scanner(System.in);
    private UserRepository repository = new UserRepository();

    @Override
    public User addUser() {
        System.out.print("Enter ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Account Number: ");
        long accNo = scanner.nextLong();
        System.out.print("Enter Phone Number: ");
        long phone = scanner.nextLong();
        System.out.print("Enter Balance: ");
        double balance = scanner.nextDouble();
        System.out.print("Enter PIN: ");
        int pin = scanner.nextInt();
        return new User(id, name, accNo, phone, balance, pin);
    }

    @Override
    public void getAllUsers(Set<User> users) {
        for (User user : users) {
            System.out.println(user);
        }
    }

    @Override
    public User getUserById(Set<User> users, int id) {
        for (User user : users) {
            if (user.getId() == id) return user;
        }
        return null;
    }

    @Override
    public Set<User> updateUser(Set<User> users, int id) {
        User toUpdate = null;
        for (User user : users) {
            if (user.getId() == id) {
                toUpdate = user;
                break;
            }
        }
        if (toUpdate != null) {
            users.remove(toUpdate);
            System.out.print("Enter new name: ");
            scanner.nextLine();
            toUpdate.setName(scanner.nextLine());
            System.out.print("Enter new phone: ");
            toUpdate.setPhoneNumber(scanner.nextLong());
            System.out.print("Enter new balance: ");
            toUpdate.setBalance(scanner.nextDouble());
            users.add(toUpdate);
        }
        return users;
    }

    @Override
    public Set<User> deleteUser(Set<User> users, int id) {
        users.removeIf(user -> user.getId() == id);
        return users;
    }

}

