package com.axisbank;

import java.util.*;

public class UserInterface {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserService userService = new UserService();
        UserRepository userRepository = new UserRepository();
        Set<User> users = userRepository.loadUsers();

        while (true) {
            System.out.println("\n--- Bank Account Management System ---");
            System.out.println("1. Add User\n2. View All Users\n3. View User by ID\n4. Update User\n5. Delete User\n6. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    users.add(userService.addUser());
                    break;
                case 2:
                    userService.getAllUsers(users);
                    break;
                case 3:
                    System.out.print("Enter ID: ");
                    User user = userService.getUserById(users, scanner.nextInt());
                    System.out.println(user != null ? user : "User not found.");
                    break;
                case 4:
                    System.out.print("Enter ID to update: ");
                    users = userService.updateUser(users, scanner.nextInt());
                    break;
                case 5:
                    System.out.print("Enter ID to delete: ");
                    users = userService.deleteUser(users, scanner.nextInt());
                    break;
                case 6:
                    System.out.println("Exiting... Goodbye!");
                    userRepository.saveUsers(users);
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Try again.");
            }
            userRepository.saveUsers(users);
        }
    }
}